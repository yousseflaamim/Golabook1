import java.util.ArrayList;
import java.util.Scanner;

public class Adminstrator implements InfoPerson{
    private String name, city,street;
    private int numberphone,numberphone2,cap,numerdorre;
     public String scan;
     Scanner scanner=new Scanner(System.in);
     ArrayList<"Ulugbek>
    public Adminstrator(String name, String city, String street, int numberphone, int numberphone2, int cap, int numerdorre) {
        this.name = name;
        this.city = city;
        this.street = street;
        this.numberphone = numberphone;
        this.numberphone2 = numberphone2;
        this.cap = cap;
        this.numerdorre = numerdorre;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public int getNumberphone() {
        return numberphone;
    }

    public void setNumberphone(int numberphone) {
        this.numberphone = numberphone;
    }

    public int getNumberphone2() {
        return numberphone2;
    }

    public void setNumberphone2(int numberphone2) {
        this.numberphone2 = numberphone2;
    }

    public int getCap() {
        return cap;
    }

    public void setCap(int cap) {
        this.cap = cap;
    }

    public int getNumerdorre() {
        return numerdorre;
    }

    public void setNumerdorre(int numerdorre) {
        this.numerdorre = numerdorre;
    }

    @Override
    public boolean addContact() {
        return false;
    }

    @Override
    public void sLector(String name) {

    }

    @Override
    public void selectAll() {

    }
    private void delete(String name){

    }
}
