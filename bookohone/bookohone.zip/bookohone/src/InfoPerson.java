public interface InfoPerson {

    public boolean addContact();
    public void sLector(String name);
    public  void selectAll();
}
