public class Vistory  extends Adminstrator implements InfoPerson{

    public Vistory(String name, String city, String street, int numberphone, int numberphone2, int cap, int numerdorre) {
        super(name, city, street, numberphone, numberphone2, cap, numerdorre);


    }

    @Override
    public boolean addContact() {
        return false;
    }

    @Override
    public void sLector(String name) {

    }

    @Override
    public void selectAll() {

    }
}
